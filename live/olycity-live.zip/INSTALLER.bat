@echo off
title OLYCITY LIVE - Installation

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo   Node.js requis. Telechargement...
    start https://nodejs.org/dist/v20.19.0/node-v20.19.0-x64.msi
    echo   Installe Node.js puis relance ce fichier en administrateur.
    pause & exit /b
)
cd /d "%~dp0"
call npm install --silent 2>nul
schtasks /delete /tn "OlycityLive" /f >nul 2>&1
schtasks /create /tn "OlycityLive" /tr "wscript.exe \"%~dp0silent.vbs\"" /sc ONLOGON /rl HIGHEST /f >nul 2>&1
if %errorlevel% neq 0 ( echo   Relance en administrateur. & pause & exit /b )
start "" wscript.exe "%~dp0silent.vbs"
echo   OLYCITY LIVE installe et demarre. Ouvre le site, onglet Live.
pause
