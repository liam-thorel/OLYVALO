OLYCITY LIVE
============

1. Clic droit sur INSTALLER.bat -> Executer en administrateur
2. C'est tout. Le script demarre automatiquement au lancement de Windows.

Pour desinstaller : DESINSTALLER.bat

Site : https://liam-thorel.github.io/OLYVALO
